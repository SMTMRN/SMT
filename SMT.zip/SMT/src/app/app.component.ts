import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  tooldzJson = [{
    type:"POWER TOOLS",
    image:"powertools",
    price:"30000",
    model:"5000w"
  },
  {
    type:"COMPRESSER",
    image:"powertools",
    price:"30000",
    model:"5000w"
  },
  {
    type:"WELDING TOOLS",
    image:"powertools",
    price:"30000",
    model:"5000w"
  },
  {
    type:"GARDEN TOOLS",
    image:"powertools",
    price:"30000",
    model:"5000w"
  },
  {
    type:"HAND TOOLS",
    image:"powertools",
    price:"30000",
    model:"5000w"
  },
  {
    type:"air TOOLS",
    image:"powertools",
    price:"30000",
    model:"5000w"
  },
  {
    type:"digital TOOLS",
    image:"powertools",
    price:"30000",
    model:"5000w"
  },
  {
    type:"VACCUM TOOLS",
    image:"powertools",
    price:"30000",
    model:"5000w"
  }
]
}
